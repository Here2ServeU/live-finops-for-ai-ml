# Catch a cost spike on day one, not at the end of the month.  Run: python3 module-3/anomaly.py
# A day is an anomaly when spend is more than 1.5x the median of the 14 days before it, and at least $50 more.
# Each alert goes to the team's owner. Spend with no team has no one to alert.
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lab"))
import history

budgets = json.load(open("lab/budgets.json"))
h = history.load()
alerts = 0
for team, days in h.items():
    for d in range(15, history.TODAY + 1):
        normal = history.median([days[x] for x in range(d - 14, d)])
        if days[d] > 1.5 * normal and days[d] - normal >= 50:
            owner = budgets.get(team, {}).get("owner", "NOBODY (untagged)")
            print(f"ALERT day {d}: {team} spent ${days[d]:,.0f} (normal ${normal:,.0f}, {days[d] / normal:.0f}x) -> {owner}")
            alerts += 1
print(f"\n{alerts} alert(s)." if alerts else "No anomalies.")
