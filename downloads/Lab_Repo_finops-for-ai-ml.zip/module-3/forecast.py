# Will each team stay inside its budget this month?  Run: python3 module-3/forecast.py
# Today is day 20 of the month. Forecast = spent so far + (typical daily spend x days left).
# OK under 90% of budget · WARN 90-100% · OVER above 100% · NO OWNER when spend has no team.
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lab"))
import history

budgets = json.load(open("lab/budgets.json"))
h = history.load()
print(f"Day {history.TODAY - history.MONTH_START + 1} of {history.MONTH_END - history.MONTH_START + 1}\n")
print(f"{'team':<10} {'so far':>8} {'per day':>8} {'forecast':>9} {'budget':>8} {'used':>6}  status")
for team, days in h.items():
    mtd, rate, fc = history.forecast(days)
    if team not in budgets or team.startswith("_"):
        print(f"{team:<10} {'$' + format(mtd, ',.0f'):>8} {'$' + format(rate, ',.0f'):>8} {'$' + format(fc, ',.0f'):>9} {'-':>8} {'-':>6}  NO OWNER: nobody will act on this")
        continue
    b = budgets[team]["budget"]
    status = "OVER" if fc > b else ("WARN" if fc > 0.9 * b else "OK")
    print(f"{team:<10} {'$' + format(mtd, ',.0f'):>8} {'$' + format(rate, ',.0f'):>8} {'$' + format(fc, ',.0f'):>9} {'$' + format(b, ',.0f'):>8} {fc / b:>6.0%}  {status}")
