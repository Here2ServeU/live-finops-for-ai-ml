# A cost check before anything is created, like a test in CI.  Run: python3 module-3/cost_gate.py module-3/change-ok.json
# Three rules: every resource is tagged; any dev GPU stops itself when idle; the new monthly cost fits the team's budget.
# Exit 0 = PASS, 1 = FAIL (so a pipeline can stop the change).
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lab"))
import history

PRICES = json.load(open("lab/prices.json"))
budgets = json.load(open("lab/budgets.json"))
REQUIRED = ["team", "model", "env"]


def check(change, forecast_for_team):
    reasons, monthly = [], 0.0
    for r in change["resources"]:
        monthly += r["count"] * r["hours_per_day"] * 30 * PRICES[r["sku"]]["on_demand"]
        missing = [t for t in REQUIRED if not r.get("tags", {}).get(t)]
        if missing:
            reasons.append(f"{r['id']}: missing tags {', '.join(missing)}")
        if r["sku"].startswith("gpu") and r.get("tags", {}).get("env") == "dev" and not r.get("auto_stop"):
            reasons.append(f"{r['id']}: dev GPU without auto_stop")
    team = change["team"]
    budget = budgets.get(team, {}).get("budget", 0)
    if forecast_for_team + monthly > budget:
        reasons.append(f"+${monthly:,.0f}/month takes {team} to ${forecast_for_team + monthly:,.0f} against a ${budget:,.0f} budget: needs owner approval")
    return monthly, reasons


if __name__ == "__main__":
    change = json.load(open(sys.argv[1] if len(sys.argv) > 1 else "module-3/change-ok.json"))
    _, _, fc = history.forecast(history.load()[change["team"]])
    monthly, reasons = check(change, fc)
    print(f"change: {change['name']} ({change['team']})  ·  estimated +${monthly:,.0f} per month")
    for r in reasons:
        print(f"  [FAIL] {r}")
    print("RESULT: " + ("FAIL" if reasons else "PASS"))
    sys.exit(1 if reasons else 0)
