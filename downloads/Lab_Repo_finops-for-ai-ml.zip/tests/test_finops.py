# Robot checks for the lab.  Run: python3 -m unittest discover tests
import json, subprocess, sys, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "lab")); sys.path.insert(0, str(ROOT / "module-3"))
import history
from cost_gate import check


def run(script, *args):
    return subprocess.run([sys.executable, script, *args], cwd=ROOT, capture_output=True, text=True)


class FinOpsLab(unittest.TestCase):
    def test_tag_audit_reports_a_share_and_a_result(self):
        r = run("module-1/tag_audit.py")
        self.assertIn("Spend with no team tag", r.stdout)
        self.assertEqual(r.returncode, 0 if "PASS" in r.stdout else 1)

    def test_unused_gpu_is_marked_for_deletion(self):
        self.assertIn("notebook-gpu-03       720       0   100%       $720  DELETE", run("module-2/idle.py").stdout)

    def test_cheapest_llm_strategy_fails_quality(self):
        out = run("module-2/llm_router.py").stdout
        self.assertIn("all small", out)
        self.assertRegex(out, r"all small .* FAIL")

    def test_forecast_uses_median_not_spike(self):
        self.assertLess(history.forecast(history.load()["research"])[1], 50)

    def test_gate_passes_small_tagged_change(self):
        self.assertEqual(check(json.load(open(ROOT / "module-3/change-ok.json")), 1900)[1], [])

    def test_gate_blocks_untagged_always_on_dev_gpu(self):
        reasons = check(json.load(open(ROOT / "module-3/change-bad.json")), 0)[1]
        self.assertTrue(any("missing tags model" in r for r in reasons))
        self.assertTrue(any("auto_stop" in r for r in reasons))


if __name__ == "__main__":
    unittest.main()
