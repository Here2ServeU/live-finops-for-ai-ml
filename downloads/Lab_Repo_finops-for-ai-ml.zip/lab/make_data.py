# Make one month of pretend cloud bills and usage for an AI team.  Run: python3 lab/make_data.py
# Writes:
#   data/bill.csv       one line per resource per day: cost, usage, tags (team, model, env)
#   data/usage.csv      business volume per day: predictions served, assistant chats
#   data/gpu_util.csv   GPU utilisation per resource per hour
#   data/history.csv    90 days of daily spend per team (for budgets and anomalies)
import csv, json, random
from pathlib import Path

rng = random.Random(7)
PRICES = json.load(open(Path(__file__).with_name("prices.json")))
DAYS = 30

# resource id, sku, units per day (hours or GB), tags. A blank tag = someone forgot to tag it.
RESOURCES = [
    ("train-gpu-01",   "gpu.large",  None, {"team": "fraud",   "model": "fraud-v2",  "env": "dev"}),
    ("train-gpu-02",   "gpu.large",  None, {"team": "fraud",   "model": "fraud-v2",  "env": "dev"}),
    ("notebook-gpu-01","gpu.small",  24,   {"team": "research","model": "",          "env": "dev"}),
    ("notebook-gpu-02","gpu.small",  24,   {"team": "",        "model": "",          "env": ""}),
    ("notebook-gpu-03","gpu.small",  24,   {"team": "",        "model": "",          "env": ""}),
    ("fraud-api-1",    "cpu.medium", 24,   {"team": "fraud",   "model": "fraud-v2",  "env": "prod"}),
    ("fraud-api-2",    "cpu.medium", 24,   {"team": "fraud",   "model": "fraud-v2",  "env": "prod"}),
    ("fraud-api-3",    "cpu.medium", 24,   {"team": "fraud",   "model": "fraud-v2",  "env": "prod"}),
    ("datasets",       "storage",    6000 / DAYS, {"team": "fraud", "model": "fraud-v2", "env": "prod"}),
    ("old-snapshots",  "storage",    9000 / DAYS, {"team": "",  "model": "",          "env": ""}),
    ("monitoring",     "cpu.medium", 48,   {"team": "shared",  "model": "",          "env": "prod"}),
]


TRAIN = {(rid, d): (0 if d % 7 in (5, 6) else rng.randint(6, 10))      # training runs on weekdays, 6-10 hours
         for rid in ("train-gpu-01", "train-gpu-02") for d in range(1, DAYS + 1)}


def write(path, header, rows):
    with open(path, "w", newline="") as f:
        w = csv.writer(f); w.writerow(header); w.writerows(rows)


def main():
    Path("data").mkdir(exist_ok=True)
    bill, util = [], []
    for day in range(1, DAYS + 1):
        for rid, sku, per_day, tags in RESOURCES:
            qty = TRAIN[(rid, day)] if per_day is None else per_day
            if qty == 0:
                continue
            cost = round(qty * PRICES[sku]["on_demand"], 2)
            bill.append([day, rid, sku, round(qty, 2), PRICES[sku]["unit"], cost, tags["team"], tags["model"], tags["env"]])
        # GPU utilisation: training is busy while it runs; notebooks are busy ~3 working hours a weekday.
        for rid, sku, per_day, tags in RESOURCES:
            if not sku.startswith("gpu"):
                continue
            busy = set()
            if rid.startswith("train"):
                busy = set(range(9, 9 + TRAIN[(rid, day)]))
            elif day % 7 not in (5, 6) and rid != "notebook-gpu-03":       # notebook-gpu-03 is forgotten entirely
                busy = set(rng.sample(range(9, 18), 3))
            hours = range(24) if per_day == 24 or rid.startswith("notebook") else sorted(busy)
            for h in hours:
                u = rng.randint(70, 98) if h in busy else rng.randint(0, 3)
                util.append([day, h, rid, u])
    # The LLM assistant is billed by tokens, not hours.
    usage = []
    for day in range(1, DAYS + 1):
        weekend = day % 7 in (5, 6)
        preds = int(rng.gauss(260000 if not weekend else 180000, 15000))
        chats = int(rng.gauss(4000 if not weekend else 1500, 300))
        tin, tout = chats * 1500, chats * 300                              # tokens per chat: 1,500 in, 300 out
        cost = round(tin / 1e6 * PRICES["llm.large"]["input"] + tout / 1e6 * PRICES["llm.large"]["output"], 2)
        bill.append([day, "assistant-llm", "llm.large", round((tin + tout) / 1e6, 3), "1M tokens", cost, "support", "assistant", "prod"])
        usage.append([day, preds, chats])
    write("data/bill.csv", ["day", "resource", "sku", "usage", "unit", "cost", "team", "model", "env"], bill)
    write("data/usage.csv", ["day", "predictions", "chats"], usage)
    write("data/gpu_util.csv", ["day", "hour", "resource", "util_pct"], util)

    # 90 days of daily spend per team, for budgets and anomaly detection.
    hist = []
    base = {"fraud": 67, "research": 24, "support": 40, "shared": 10, "untagged": 54}
    for day in range(1, 91):
        for team, b in base.items():
            spend = b * (0.75 if day % 7 in (5, 6) else 1.0) * rng.uniform(0.92, 1.08)
            if team == "support":
                spend *= 1 + day * 0.004                                    # the assistant gets more popular every week
            if team == "research" and day in (74, 75, 76):
                spend += 8 * 24 * PRICES["gpu.large"]["on_demand"]          # someone left 8 big GPUs running
            hist.append([day, team, round(spend, 2)])
    write("data/history.csv", ["day", "team", "spend"], hist)
    # 2,000 assistant requests for the routing lab. 'hard' is the hidden truth used only to score quality.
    faqs = [f"How do I reset my card PIN? (variant {i})" if i < 3 else q for i, q in enumerate([
        "", "", "", "What is my daily card limit?", "How do I freeze my card?", "Where can I see my statement?",
        "How long does a refund take?", "How do I change my address?", "Is there a fee for foreign payments?",
        "How do I report a lost card?", "Can I get a new PIN by text?", "What time does support open?"])]
    hard_topics = ["dispute with three merchants and a partial refund", "two payments flagged as fraud while travelling",
                   "chargeback on a subscription I cancelled", "an investigation that has been open for 45 days"]
    with open("data/requests.jsonl", "w") as f:
        for i in range(2000):
            roll = rng.random()
            if roll < 0.60:
                q, hard = rng.choice(faqs), False
            elif roll < 0.85:
                q, hard = f"Can you check payment {rng.randint(1000, 9999)} from {rng.randint(1, 28)} October?", False
            else:
                q = f"Please explain why my case about {rng.choice(hard_topics)} is taking so long and compare my options."
                hard = True
            f.write(json.dumps({"id": i + 1, "prompt": q, "hard": hard}) + "\n")
    total = sum(r[5] for r in bill)
    print(f"wrote data/bill.csv ({len(bill)} lines, ${total:,.0f} this month), usage.csv, gpu_util.csv, history.csv (90 days)")


if __name__ == "__main__":
    main()
