# Shared helper: daily spend per team from data/history.csv.
import csv
from collections import defaultdict

MONTH_START, TODAY, MONTH_END = 61, 80, 90


def load(path="data/history.csv"):
    h = defaultdict(dict)
    for r in csv.DictReader(open(path)):
        h[r["team"]][int(r["day"])] = float(r["spend"])
    return h


def median(xs):
    s = sorted(xs); n = len(s)
    return s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2


def forecast(days):
    """Month-to-date spend + a robust run rate (median of the last 7 days) x days left."""
    mtd = sum(days[d] for d in range(MONTH_START, TODAY + 1))
    rate = median([days[d] for d in range(TODAY - 6, TODAY + 1)])
    return mtd, rate, mtd + rate * (MONTH_END - TODAY)
