# Shared helper: read the bill once, the same way, in every script.
import csv, json
from collections import defaultdict
from pathlib import Path

TAG_FIXES = Path(__file__).resolve().parent.parent / "module-1" / "tags.json"


def load(path="data/bill.csv"):
    """Read the bill. If module-1/tags.json exists, fill in missing tags from it (never overwrite existing ones)."""
    fixes = json.load(open(TAG_FIXES)) if TAG_FIXES.exists() else {}
    rows = []
    with open(path) as f:
        for r in csv.DictReader(f):
            r["cost"] = float(r["cost"]); r["usage"] = float(r["usage"]); r["day"] = int(r["day"])
            for tag, value in fixes.get(r["resource"], {}).items():
                r[tag] = r[tag] or value
            rows.append(r)
    return rows


def total_by(rows, key):
    out = defaultdict(float)
    for r in rows:
        out[key(r)] += r["cost"]
    return dict(sorted(out.items(), key=lambda kv: -kv[1]))


def money(x):
    return f"${x:,.0f}"
