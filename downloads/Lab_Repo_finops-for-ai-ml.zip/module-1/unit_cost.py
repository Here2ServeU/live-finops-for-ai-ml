# What does one unit of value cost?  Run: python3 module-1/unit_cost.py
# Unit economics turns "the bill went up" into "each prediction got cheaper" (or not).
import csv, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lab"))
from bill import load, money

rows = load()
usage = list(csv.DictReader(open("data/usage.csv")))
preds = sum(int(u["predictions"]) for u in usage)
chats = sum(int(u["chats"]) for u in usage)

fraud_serve = sum(r["cost"] for r in rows if r["model"] == "fraud-v2" and r["env"] == "prod")
fraud_train = sum(r["cost"] for r in rows if r["model"] == "fraud-v2" and r["env"] == "dev")
assistant = sum(r["cost"] for r in rows if r["model"] == "assistant")

print(f"Fraud model   serving {money(fraud_serve)} for {preds:,} predictions")
print(f"              = ${fraud_serve / preds * 1000:.3f} per 1,000 predictions")
print(f"              training {money(fraud_train)} this month (serving + training = ${(fraud_serve + fraud_train) / preds * 1000:.3f} per 1,000)")
print(f"Assistant     {money(assistant)} for {chats:,} chats = ${assistant / chats:.3f} per chat")
