# Who owns this?  Run: python3 module-1/tag_audit.py
# Every resource needs three tags: team, model, env. Spend without a team has no owner:
# nobody gets the bill, nobody gets the alert, nobody turns it off.
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lab"))
from bill import load, total_by, money

REQUIRED = ["team", "model", "env"]
rows = load()
total = sum(r["cost"] for r in rows)
untagged = [r for r in rows if not r["team"]]
share = sum(r["cost"] for r in untagged) / total
print(f"Spend with no team tag: {money(share * total)} of {money(total)} = {share:.0%}")
print("\nUntagged resources (no owner):")
for rid, c in total_by(untagged, lambda r: r["resource"]).items():
    print(f"  {rid:<16} {money(c):>8}")
print("\nMissing tags by resource:")
seen = {}
for r in rows:
    missing = [t for t in REQUIRED if not r[t]]
    if missing and r["resource"] not in seen:
        seen[r["resource"]] = missing
        print(f"  {r['resource']:<16} missing {', '.join(missing)}")
target = 0.05
print(f"\nRESULT: {'PASS' if share <= target else 'FAIL'} (target: at most {target:.0%} untagged)")
sys.exit(0 if share <= target else 1)
