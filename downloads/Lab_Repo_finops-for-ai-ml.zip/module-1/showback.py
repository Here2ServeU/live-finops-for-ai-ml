# Who spent what?  Run: python3 module-1/showback.py
# Showback: each team sees its own costs. Shared costs (monitoring) are split in proportion
# to each team's direct spend. Untagged spend stays UNALLOCATED, in plain sight.
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lab"))
from bill import load, total_by, money

rows = load()
by_team = total_by(rows, lambda r: r["team"] or "UNALLOCATED")
shared = by_team.pop("shared", 0.0)
unallocated = by_team.pop("UNALLOCATED", 0.0)
direct = sum(by_team.values())
print(f"{'team':<12} {'direct':>8} {'+ shared':>9} {'= total':>9}")
for team, c in by_team.items():
    part = shared * c / direct
    print(f"{team:<12} {money(c):>8} {money(part):>9} {money(c + part):>9}")
print(f"{'UNALLOCATED':<12} {money(unallocated):>8} {'':>9} {money(unallocated):>9}   <- no owner: fix the tags")
print(f"\nBy model:")
for model, c in total_by(rows, lambda r: r["model"] or "(none)").items():
    print(f"  {model:<10} {money(c):>8}")
