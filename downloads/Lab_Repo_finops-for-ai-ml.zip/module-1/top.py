# Where does the money go?  Run: python3 module-1/top.py
# The first FinOps question: total, by kind of thing (SKU), and the most expensive resources.
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lab"))
from bill import load, total_by, money

rows = load()
total = sum(r["cost"] for r in rows)
print(f"This month: {money(total)}\n\nBy SKU (what kind of thing)")
for sku, c in total_by(rows, lambda r: r["sku"]).items():
    print(f"  {sku:<11} {money(c):>8}  {c / total:5.1%}  {'#' * round(c / total * 50)}")
print("\nTop 5 resources")
for rid, c in list(total_by(rows, lambda r: r["resource"]).items())[:5]:
    print(f"  {rid:<16} {money(c):>8}")
