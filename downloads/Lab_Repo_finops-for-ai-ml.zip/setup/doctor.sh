#!/usr/bin/env bash
# FinOps for AI-ML - check your machine.  Run: bash setup/doctor.sh
ok()   { printf "  [ OK ]  %s\n" "$1"; }
warn() { printf "  [WARN]  %s\n" "$1"; }
echo "FinOps for AI-ML - doctor"; echo "-------------------------"
[ "$(uname -s)" = "Linux" ] && ok "Linux ($(uname -r | cut -d- -f1))" || warn "not Linux: use Codespaces, WSL Ubuntu or a Multipass VM"
command -v python3 >/dev/null && ok "$(python3 --version)" || warn "Python 3 missing: sudo apt install python3"
python3 -c 'import sys; sys.exit(sys.version_info < (3, 9))' 2>/dev/null && ok "Python 3.9 or newer" || warn "Python too old: need 3.9+"
command -v git >/dev/null && ok "$(git --version)" || warn "git missing: sudo apt install git"
[ -f data/bill.csv ] && ok "lab data ready" || warn "lab data missing: python3 lab/make_data.py"
echo "-------------------------"
echo "Standard-library Python only: nothing to pip install, no cloud account, no GPU."
