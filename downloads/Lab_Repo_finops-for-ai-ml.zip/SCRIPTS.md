# Lab scripts: what each one is and what it does

FinOps for AI-ML Systems · T2S · Emmanuel Naweji

Standard-library Python only. Run everything from the repo folder. All prices are made-up lab prices (`lab/prices.json`).

| Script | What it is | What it does | Module |
|---|---|---|---|
| `setup/doctor.sh` | The health check | Linux, Python 3.9+, git, lab data | all |
| `lab/make_data.py` | The data maker | One month of bills, usage, GPU utilisation, 2,000 assistant requests, 90 days of team spend | all |
| `lab/prices.json` | The price list | Lab prices for GPUs, CPUs, storage and LLM tokens | all |
| `lab/bill.py` · `lab/history.py` | Shared helpers | Read the bill (with tag fixes) and team spend the same way everywhere | all |
| `module-1/top.py` | Where the money goes | Total, by SKU, top 5 resources | 1 |
| `module-1/tag_audit.py` | Who owns this? | Untagged share, untagged resources, missing tags; PASS at ≤ 5% | 1 |
| `module-1/showback.py` | Who spent what | Cost by team with shared costs split fairly; UNALLOCATED stays visible | 1 |
| `module-1/unit_cost.py` | Unit economics | Cost per 1,000 predictions and per assistant chat | 1 |
| `module-1/tags.example.json` | Tag fixes | Fills in missing tags (copy to `tags.json`) | 1 |
| `module-2/idle.py` | Idle GPU finder | Busy vs idle hours per GPU; DELETE or AUTO-STOP; monthly saving | 2 |
| `module-2/spot_sim.py` | Spot simulator | On-demand vs spot, with and without checkpoints, 500 runs each | 2 |
| `module-2/llm_router.py` | LLM cost strategies | All-large, all-small, routing, routing + cache, against a 95% quality floor | 2 |
| `module-3/forecast.py` | Budget forecast | Month-to-date + median daily run rate → OK / WARN / OVER / NO OWNER | 3 |
| `module-3/anomaly.py` | Spike detector | Day > 1.5× the 14-day median (and +$50) → alert to the owner | 3 |
| `module-3/cost_gate.py` | Cost gate | Tags, auto-stop, budget headroom for a proposed change; exit 0/1 | 3 |
| `tests/` | Robot checks | 6 checks: `python3 -m unittest discover tests` | all |

---

## lab/make_data.py — the data maker
**Run:** `python3 lab/make_data.py` → `wrote data/bill.csv (344 lines, $5,778 this month), usage.csv, gpu_util.csv, history.csv (90 days)`
Fixed seed, so everyone sees the same numbers. The pretend company has: two training GPUs (weekdays only), three notebook GPUs running 24/7 (one forgotten, two untagged), three CPU servers for the fraud API, storage (including untagged old snapshots), shared monitoring, and an LLM assistant billed per token.

## module-1/top.py — where the money goes
**Run:** `python3 module-1/top.py`
This month **$5,778**. By SKU: gpu.small $2,160 (37%), gpu.large $1,384 (24%), llm.large $1,214 (21%), cpu.medium $720, storage $300. The surprise: the notebook GPUs cost more than training.

## module-1/tag_audit.py — who owns this?
**Run:** `python3 module-1/tag_audit.py` (exit 1 when more than 5% is untagged)
**$1,620 of $5,778 = 28%** has no team tag: notebook-gpu-02, notebook-gpu-03 ($720 each), old-snapshots ($180). Then every resource missing team, model or env.
**Fix:** `cp module-1/tags.example.json module-1/tags.json` and run again → 0%, PASS. `lab/bill.py` fills in only missing tags; it never overwrites a tag.

## module-1/showback.py — who spent what
**Run:** `python3 module-1/showback.py`
Direct cost per team, plus a share of `shared` (monitoring) in proportion to direct spend, plus an UNALLOCATED line. Before the tag fix: fraud $2,080, support $1,305, research $774, UNALLOCATED $1,620. After: research becomes the biggest spender ($2,273).

## module-1/unit_cost.py — unit economics
**Run:** `python3 module-1/unit_cost.py`
Fraud model: $552 serving for 7,177,548 predictions = **$0.077 per 1,000 predictions** ($0.270 including training). Assistant: $1,214 for 101,178 chats = **$0.012 per chat**.

## module-2/idle.py — idle GPUs
**Run:** `python3 module-2/idle.py`
An hour is idle under 10% utilisation. notebook-gpu-01 and -02: 91% idle → AUTO-STOP after 1 idle hour. notebook-gpu-03: 0 busy hours → DELETE. Training GPUs: busy whenever billed. **Estimated saving: $1,897 per month.**

## module-2/spot_sim.py — spot GPUs
**Run:** `python3 module-2/spot_sim.py`
A 40 GPU-hour training job, 8% chance of interruption per hour, 500 simulated runs per option.

| Option | Avg hours | Avg cost | Finished |
|---|---|---|---|
| on-demand | 40.0 | $160 | 100% |
| spot, no checkpoints | 229.2 | $275 | 76% |
| spot, checkpoint 60 min | 43.4 | $52 | 100% |
| spot, checkpoint 15 min | 45.8 | $55 | 100% |

Spot is only cheap if the job can survive interruptions.

## module-2/llm_router.py — LLM cost strategies
**Run:** `python3 module-2/llm_router.py`
2,000 requests (1,500 tokens in, 300 out). The small model is good at easy questions and weak at hard ones. Quality floor 95%.

| Strategy | Per 1k requests | Per month | Quality | Verdict |
|---|---|---|---|---|
| all large | $12.00 | $1,214 | 97.9% | PASS |
| all small | $1.20 | $121 | 90.2% | FAIL |
| route | $2.87 | $290 | 97.2% | PASS |
| route + cache | $1.01 | $102 | 98.9% | PASS |

The router sends long or "explain / compare / why" questions to the large model. The cache reuses only answers that were good and contain no personal details (no digits).

## module-3/forecast.py — budget forecast
**Run:** `python3 module-3/forecast.py` (day 20 of 30)
Forecast = month-to-date + median of the last 7 days × 10 days left. fraud 86% OK · research 374% OVER · support 96% WARN · shared 88% OK · untagged $1,558 NO OWNER. The median ignores the 3-day spike, so the run rate stays honest.

## module-3/anomaly.py — spike detector
**Run:** `python3 module-3/anomaly.py`
`ALERT day 74: research spent $791 (normal $22, 36x) -> research-lead@example.com` (and days 75, 76). Someone left 8 big GPUs running. An alert on day 74 is the difference between one bad day and three.

## module-3/cost_gate.py — cost gate
**Run:** `python3 module-3/cost_gate.py module-3/change-ok.json` → +$144/month, PASS (exit 0)
`python3 module-3/cost_gate.py module-3/change-bad.json` → +$11,520/month, FAIL (exit 1): missing tag `model`, dev GPU without `auto_stop`, and over the research budget without owner approval.

---

**In real life:** `bill.csv` → AWS Cost and Usage Report / Azure Cost Management exports / GCP billing export to BigQuery, or the FOCUS open billing format · tags → cloud resource tags/labels enforced by policy · `idle.py` → GPU metrics (DCGM, CloudWatch) + scheduled shutdown · `forecast.py` / `anomaly.py` → AWS Budgets & Cost Anomaly Detection, Azure budgets, GCP budget alerts · `cost_gate.py` → Infracost or policy-as-code in CI.
