# Spot GPUs: 70% cheaper, but they can be taken back at any moment.  Run: python3 module-2/spot_sim.py
# A training job needs 40 GPU-hours of work. On spot, each hour has an 8% chance of interruption.
# Checkpointing saves progress every N minutes (each save costs 2 minutes); without it, an interruption loses everything.
import json, random

PRICES = json.load(open("lab/prices.json"))["gpu.large"]
WORK_H, P_INTERRUPT, SAVE_MIN, RUNS = 40, 0.08, 2, 500


def run(rng, spot, every_min):
    done = since_save = clock = 0.0                    # hours of real progress, progress since last save, hours billed
    step = 1 / 60
    while done < WORK_H:
        clock += step
        if spot and rng.random() < P_INTERRUPT * step:  # interruption: lose unsaved progress, restart
            done -= since_save; since_save = 0.0
            clock += 0.1                                # ~6 minutes to get a new machine
            continue
        done += step; since_save += step
        if every_min and since_save >= every_min / 60:
            clock += SAVE_MIN / 60; since_save = 0.0
        if clock > 400:
            return clock, False                         # gave up: never finished
    return clock, True


rng = random.Random(1)
print(f"Training job: {WORK_H} GPU-hours of work · on-demand ${PRICES['on_demand']:.2f}/h · spot ${PRICES['spot']:.2f}/h\n")
print(f"{'option':<26} {'avg hours':>9} {'avg cost':>9} {'finished':>9}")
for name, spot, every in [("on-demand", False, 0), ("spot, no checkpoints", True, 0),
                          ("spot, checkpoint 60 min", True, 60), ("spot, checkpoint 15 min", True, 15)]:
    results = [run(rng, spot, every) for _ in range(RUNS)]
    hours = sum(h for h, _ in results) / RUNS
    ok = sum(f for _, f in results) / RUNS
    price = PRICES["spot"] if spot else PRICES["on_demand"]
    print(f"{name:<26} {hours:>9.1f} {'$' + format(hours * price, ',.0f'):>9} {ok:>9.0%}")
