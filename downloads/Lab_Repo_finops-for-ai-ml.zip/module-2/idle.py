# Which GPUs are we paying to wait?  Run: python3 module-2/idle.py
# A GPU hour counts as idle when utilisation is under 10%. You pay the same either way.
import csv, json, sys
from collections import defaultdict
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lab"))
from bill import money

PRICES = json.load(open("lab/prices.json"))
SKU = {"train-gpu-01": "gpu.large", "train-gpu-02": "gpu.large",
       "notebook-gpu-01": "gpu.small", "notebook-gpu-02": "gpu.small", "notebook-gpu-03": "gpu.small"}
hours, busy = defaultdict(int), defaultdict(int)
for r in csv.DictReader(open("data/gpu_util.csv")):
    hours[r["resource"]] += 1
    busy[r["resource"]] += int(r["util_pct"]) >= 10

print(f"{'resource':<16} {'billed h':>8} {'busy h':>7} {'idle':>6} {'idle cost':>10}  action")
saved = 0.0
for rid in sorted(hours):
    price = PRICES[SKU[rid]]["on_demand"]
    idle_h = hours[rid] - busy[rid]
    idle_cost = idle_h * price
    if busy[rid] == 0:
        action, save = "DELETE: never used this month", idle_cost
    elif idle_h / hours[rid] > 0.5:
        action, save = "AUTO-STOP after 1 idle hour", idle_cost * 0.9      # keep a 10% buffer for warm-up
    else:
        action, save = "ok: busy when billed", 0.0
    saved += save
    print(f"{rid:<16} {hours[rid]:>8} {busy[rid]:>7} {idle_h / hours[rid]:>6.0%} {money(idle_cost):>10}  {action}")
print(f"\nEstimated saving: {money(saved)} per month")
