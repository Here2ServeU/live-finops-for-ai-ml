# Cheaper LLM bills without worse answers.  Run: python3 module-2/llm_router.py
# 2,000 real-looking assistant requests, four strategies, one quality floor: at least 95% good answers.
import json, random

PRICES = json.load(open("lab/prices.json"))
TOKENS_IN, TOKENS_OUT, FLOOR, CHATS_PER_MONTH = 1500, 300, 0.95, 101178
requests = [json.loads(l) for l in open("data/requests.jsonl")]


def cost(model):
    p = PRICES[model]
    return TOKENS_IN / 1e6 * p["input"] + TOKENS_OUT / 1e6 * p["output"]


def good_answer(req, model):
    """Stand-in for a quality check: the small model struggles with hard questions."""
    chance = {"llm.large": (0.98, 0.96), "llm.small": (0.97, 0.55)}[model][req["hard"]]
    return random.Random(f"{req['id']}-{model}").random() < chance


def needs_large(req):
    """The router: long or 'explain/compare/why' questions go to the large model."""
    p = req["prompt"].lower()
    return len(p) > 90 or any(w in p for w in ("explain", "compare", "why"))


def simulate(strategy):
    spent, good, cache = 0.0, 0, {}
    for req in requests:
        if strategy.endswith("+ cache") and req["prompt"] in cache:
            good += 1                                        # same question: reuse a known-good answer, no tokens
            continue
        model = {"all large": "llm.large", "all small": "llm.small"}.get(strategy) or ("llm.large" if needs_large(req) else "llm.small")
        ok = good_answer(req, model)
        spent += cost(model); good += ok
        if ok and not any(ch.isdigit() for ch in req["prompt"]):
            cache[req["prompt"]] = True                      # cache only good, non-personal answers
    return spent, good / len(requests)


print(f"{len(requests):,} requests · {TOKENS_IN} tokens in, {TOKENS_OUT} out · quality floor {FLOOR:.0%}\n")
print(f"{'strategy':<16} {'per 1k req':>10} {'per month':>10} {'quality':>8}  verdict")
for s in ["all large", "all small", "route", "route + cache"]:
    spent, q = simulate(s)
    per_k = spent / len(requests) * 1000
    verdict = "PASS" if q >= FLOOR else "FAIL: too many bad answers"
    print(f"{s:<16} {'$' + format(per_k, '.2f'):>10} {'$' + format(per_k * CHATS_PER_MONTH / 1000, ',.0f'):>10} {q:>8.1%}  {verdict}")
