# FinOps for AI-ML Systems

Transformed 2 Succeed (T2S) · Emmanuel Naweji

See every dollar your AI systems spend, cut the waste without hurting the models, and keep spending on budget, automatically. Three modules that follow the FinOps lifecycle: **Inform → Optimize → Operate**.

| Module | Sticky idea | Lab |
|---|---|---|
| 1 · See Every Dollar | **You can't cut what you can't see.** | A month of AI cloud bills: top costs, tag audit, showback by team, cost per 1,000 predictions and per chat |
| 2 · Cut the Waste, Not the Model | **Pay for work, not for waiting.** | Idle GPUs, spot training with checkpoints, LLM routing and caching with a quality floor |
| 3 · Budgets That Bite | **Every dollar needs an owner and an alarm.** | Budget forecasts, anomaly alerts routed to owners, a cost gate that blocks bad changes before they exist |

## Setup
Codespaces, WSL Ubuntu or a Multipass VM. Standard-library Python 3.9+ only: no pip install, no cloud account, no GPU.

```bash
git clone https://github.com/Here2ServeU/finops-for-ai-ml
cd finops-for-ai-ml
python3 lab/make_data.py
bash setup/doctor.sh
```

All prices in `lab/prices.json` are **made-up lab prices** chosen to be easy to calculate with. Real prices vary by provider, region and date.

See **SCRIPTS.md** for what every script is and what it does.
